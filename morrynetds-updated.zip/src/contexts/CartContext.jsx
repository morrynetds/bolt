import { createContext, useContext, useEffect, useMemo, useState } from 'react'

const CartContext = createContext(null)

const STORAGE_KEY = 'morrynetpro_cart'

export function CartProvider({ children }) {
  const [items, setItems] = useState([])

  useEffect(() => {
    try {
      const persisted = localStorage.getItem(STORAGE_KEY)
      if (persisted) {
        setItems(JSON.parse(persisted))
      }
    } catch {
      setItems([])
    }
  }, [])

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
  }, [items])

  const addItem = (product) => {
    setItems((current) => {
      const exists = current.find((item) => item.slug === product.slug)
      if (exists) {
        return current
      }
      return [...current, { ...product, quantity: 1 }]
    })
  }

  const removeItem = (slug) => {
    setItems((current) => current.filter((item) => item.slug !== slug))
  }

  const updateQuantity = (slug, quantity) => {
    setItems((current) =>
      current.map((item) =>
        item.slug === slug ? { ...item, quantity: Math.max(1, quantity) } : item,
      ),
    )
  }

  const clearCart = () => setItems([])

  const total = useMemo(() => items.reduce((sum, item) => sum + item.price * item.quantity, 0), [items])

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, updateQuantity, clearCart, total }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (!context) {
    throw new Error('useCart must be used within CartProvider')
  }
  return context
}
