import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY
const supabase = createClient(supabaseUrl, supabaseAnonKey)

export const deviceInfo = () => {
  const ua = navigator.userAgent
  const isMobile = /Mobi|Android/i.test(ua)
  const isTablet = /Tablet|iPad/i.test(ua)
  return {
    ipAddress: '',
    deviceType: isTablet ? 'tablet' : isMobile ? 'mobile' : 'desktop',
    deviceOs: /Windows NT/i.test(ua)
      ? 'Windows'
      : /Macintosh/i.test(ua)
      ? 'macOS'
      : /Android/i.test(ua)
      ? 'Android'
      : /iPhone|iPad|iPod/i.test(ua)
      ? 'iOS'
      : 'Unknown',
    userAgent: ua,
  }
}

export async function registerTrial(ipAddress, email) {
  const info = deviceInfo()
  const { data, error } = await supabase
    .from('trial_ips')
    .upsert({
      ip_address: ipAddress,
      device_type: info.deviceType,
      device_os: info.deviceOs,
      user_agent: info.userAgent,
      trial_started_at: new Date().toISOString(),
      trial_expires_at: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
    })
    .select()
    .single()

  return { data, error }
}
