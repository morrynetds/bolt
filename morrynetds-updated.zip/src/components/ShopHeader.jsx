import { Link } from 'react-router-dom'

export default function ShopHeader() {
  return (
    <section className="relative overflow-hidden bg-brand-950 py-24 text-white">
      <div className="container-x">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow text-brand-200">Shop & Downloads</span>
          <h1 className="mt-4 text-4xl font-extrabold sm:text-5xl">Standalone trading systems, EAS packs, and companion tools.</h1>
          <p className="mt-5 text-base leading-8 text-slate-300">
            Buy standalone HTML systems, indicator bundles, or tool kits with one-user licensing. Each product is built to deploy quickly, with subscription access and affiliate bonuses available for every purchase.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <a href="#products" className="btn-primary inline-flex items-center justify-center px-6 py-3 text-sm">
              Browse products
            </a>
            <Link to="/" className="btn-ghost inline-flex items-center justify-center px-6 py-3 text-sm">
              Back to homepage
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
