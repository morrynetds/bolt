import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
import { getDeviceInfo } from '../lib/deviceInfo'

const schemaErrorMessage = 'Registration failed because the backend database schema is not initialized. Please deploy the Supabase migrations or contact support.'

function getErrorMessage(error) {
  const message = error?.message || String(error)
  if (message.includes("Could not find the table 'public.affiliates'")) {
    return schemaErrorMessage
  }
  return message
}

export default function Signup() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    password: '',
    phone: '',
    payoutMethod: 'mpesa',
    payoutDetails: '',
  })
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [loading, setLoading] = useState(false)
  const [referrerId, setReferrerId] = useState(null)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const ref = params.get('ref')
    if (ref) setReferrerId(ref)
  }, [])

  if (user) {
    navigate('/dashboard')
    return null
  }

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    if (form.password.length < 8) {
      setError('Password must be at least 8 characters.')
      return
    }

    setLoading(true)

    try {
      const device = getDeviceInfo()
      const trialResponse = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/trial-registration`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(device),
        },
      )

      if (!trialResponse.ok) {
        const trialError = await trialResponse.json()
        throw new Error(trialError.error || 'Unable to register trial. Please try again later.')
      }

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
      })

      if (authError) throw authError

      const userId = authData.user?.id
      if (!userId) throw new Error('Account creation failed. Please try again.')

      // Fetch referrer's tree_path if a referrer exists
      let parentPath = ''
      if (referrerId) {
        const { data: referrer } = await supabase
          .from('affiliates')
          .select('tree_path')
          .eq('user_id', referrerId)
          .maybeSingle()
        if (referrer?.tree_path) {
          parentPath = referrer.tree_path
        }
      }

      const treePath = parentPath ? `${parentPath}-${userId}` : userId

      // Insert affiliate profile
      const { error: affError } = await supabase.from('affiliates').insert({
        user_id: userId,
        full_name: form.fullName,
        phone: form.phone,
        payout_method: form.payoutMethod,
        payout_details: form.payoutDetails,
        parent_id: referrerId || null,
        tree_path: treePath,
      })

      if (affError) throw affError

      // Create wallet
      const { error: walletError } = await supabase.from('wallets').insert({
        affiliate_id: userId,
        current_balance: 0,
        total_withdrawn: 0,
      })

      if (walletError) throw walletError

      // Create a 7-day free trial subscription (activated once email is verified)
      const { error: subError } = await supabase.from('subscriptions').insert({
        user_id: userId,
        status: 'trial',
        tier: 'pro',
        is_trial: true,
        email_verified: false,
        trial_expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      })

      if (subError) throw subError

      setSuccess('Account created! Check your email to verify and activate your 7-day free trial.')
      setTimeout(() => navigate('/dashboard'), 2500)
    } catch (err) {
      setError(getErrorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <section id="signup" className="relative overflow-hidden py-24">
      <div className="absolute inset-0 bg-gradient-to-b from-ink-900 to-ink-950" />
      <div className="absolute inset-0 grid-glow" />
      <div className="container-x relative">
        <div className="mx-auto max-w-md">
          <div className="text-center">
            <span className="eyebrow">Member Registration</span>
            <h2 className="mt-3 text-3xl font-extrabold text-white">Create Your Member Account</h2>
            <p className="mt-3 text-sm text-slate-400">
              Register in 30 seconds to start your subscription and unlock the trading dashboard. Your affiliate account and referral link are generated automatically.
            </p>
          </div>

          {referrerId && (
            <div className="mt-6 rounded-xl border border-ocean-500/30 bg-ocean-500/10 px-4 py-3 text-center text-sm text-ocean-400">
              You were referred by an existing affiliate. Welcome to the network!
            </div>
          )}

          {error && (
            <div className="mt-6 rounded-xl border border-danger-500/30 bg-danger-500/10 px-4 py-3 text-sm text-danger-400">
              {error}
            </div>
          )}
          {success && (
            <div className="mt-6 rounded-xl border border-brand-500/30 bg-brand-500/10 px-4 py-3 text-sm text-brand-400">
              {success}
            </div>
          )}

          <form onSubmit={handleSubmit} className="card mt-6 space-y-4 p-7">
            <div>
              <label className="label" htmlFor="fullName">Full Name</label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                required
                value={form.fullName}
                onChange={handleChange}
                className="input"
                placeholder="John Doe"
              />
            </div>
            <div>
              <label className="label" htmlFor="email">Email Address</label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={form.email}
                onChange={handleChange}
                className="input"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="label" htmlFor="phone">Phone Number (M-Pesa)</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                required
                value={form.phone}
                onChange={handleChange}
                className="input"
                placeholder="0712345678"
              />
            </div>
            <div>
              <label className="label" htmlFor="password">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                required
                minLength="8"
                value={form.password}
                onChange={handleChange}
                className="input"
                placeholder="Min 8 characters"
              />
            </div>
            <div>
              <label className="label" htmlFor="payoutMethod">Preferred Payout Method</label>
              <select
                id="payoutMethod"
                name="payoutMethod"
                required
                value={form.payoutMethod}
                onChange={handleChange}
                className="input"
              >
                <option value="mpesa">M-Pesa</option>
                <option value="paypal">PayPal</option>
              </select>
            </div>
            <div>
              <label className="label" htmlFor="payoutDetails">Payout Details (Phone or Email)</label>
              <input
                id="payoutDetails"
                name="payoutDetails"
                type="text"
                required
                value={form.payoutDetails}
                onChange={handleChange}
                className="input"
                placeholder="M-Pesa Number or PayPal Email"
              />
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? 'Creating Account...' : 'Create Member Account'}
            </button>
          </form>
        </div>
      </div>
    </section>
  )
}
