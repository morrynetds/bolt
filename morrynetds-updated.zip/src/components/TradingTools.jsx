const tools = [
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M3 3v18h18" /><path d="M7 14l4-4 3 3 5-6" />
      </svg>
    ),
    title: 'Multi-Timeframe Analysis',
    desc: 'Scan 9 timeframes simultaneously — M1 through W1 — with bullish/bearish consensus per timeframe, so you always trade in the direction of the higher trend.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="12" r="10" /><path d="M2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20" />
      </svg>
    ),
    title: 'Auto Consensus Matrix',
    desc: 'An aggregated verdict across all timeframes with an agreement score. One glance tells you whether the market is aligned long, short, or ranging.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M12 2L2 7l10 5 10-5-10-5z" /><path d="M2 17l10 5 10-5M2 12l10 5 10-5" />
      </svg>
    ),
    title: 'ICT Liquidity Mapping',
    desc: 'Detect buy-side and sell-side liquidity pools, fair value gaps (FVGs), and order blocks. Know where price is likely to sweep before the real move.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
      </svg>
    ),
    title: 'Smart Signal Engine',
    desc: 'Get strong/weak signal ratings with entry, stop-loss, and multiple take-profit targets — each with a calculated risk-to-reward ratio.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="3" y="3" width="18" height="18" rx="2" /><path d="M9 3v18M3 9h18" />
      </svg>
    ),
    title: 'Risk / Reward Calculator',
    desc: 'Built-in position sizing with live R/R ratios across 1:1, 1:2, and 1:3 targets. Never enter a trade without knowing your exact risk.',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
      </svg>
    ),
    title: 'Real-Time Price Feed',
    desc: 'Live ticker data for forex, gold, indices, and crypto. Streaming updates keep your analysis current without refreshing the page.',
  },
]

export default function TradingTools() {
  return (
    <section id="tools" className="relative py-24">
      <div className="container-x">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">ICT Trading System</span>
          <h2 className="section-title mt-3">Institutional-grade tools, retail-friendly interface</h2>
          <p className="section-sub">
            The same liquidity concepts used by prop firms and institutional desks — packaged into a clean,
            real-time dashboard anyone can use.
          </p>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {tools.map((t, i) => (
            <div
              key={t.title}
              className="card card-hover group p-7 [animation:fadeUp_0.6s_ease-out_both]"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500/20 to-ocean-500/20 text-brand-400 transition-transform group-hover:scale-110">
                {t.icon}
              </div>
              <h3 className="mt-5 text-xl font-bold text-white">{t.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-400">{t.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
