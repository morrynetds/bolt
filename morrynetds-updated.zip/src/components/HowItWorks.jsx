const steps = [
  {
    n: '1',
    title: 'Register Your Member Account',
    desc: 'Create a member account and verify your email to activate your 7-day free trial. Your affiliate account and referral link are generated automatically — full access to the ICT trading dashboard from day one.',
  },
  {
    n: '2',
    title: 'Subscribe & Share Your Link',
    desc: 'Pick a subscription plan that fits your budget — starting at just $2/day. Copy your unique referral link and share it across your network.',
  },
  {
    n: '3',
    title: 'Earn 50% of Every Sale',
    desc: 'Every subscription in your 6-tier network earns you a commission — 25% Tier 1, 10% Tier 2, 5% Tier 3, and 10% across Tiers 4-6. Paid automatically to M-Pesa.',
  },
]

export default function HowItWorks() {
  return (
    <section className="relative py-24">
      <div className="container-x">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">How It Works</span>
          <h2 className="section-title mt-3">Get started in under 2 minutes</h2>
          <p className="section-sub">No technical skills required. Three simple steps to daily recurring income.</p>
        </div>

        <div className="relative mt-16 grid gap-10 md:grid-cols-3">
          <div className="absolute left-[16%] right-[16%] top-8 hidden h-0.5 bg-gradient-to-r from-brand-500 via-ocean-500 to-brand-500 md:block" />
          {steps.map((s, i) => (
            <div
              key={s.n}
              className="relative text-center [animation:fadeUp_0.6s_ease-out_both]"
              style={{ animationDelay: `${i * 120}ms` }}
            >
              <div className="relative z-10 mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-ocean-600 text-2xl font-black text-ink-950 shadow-lg shadow-brand-500/30">
                {s.n}
              </div>
              <h3 className="mt-6 text-xl font-bold text-white">{s.title}</h3>
              <p className="mx-auto mt-3 max-w-xs text-sm leading-relaxed text-slate-400">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
