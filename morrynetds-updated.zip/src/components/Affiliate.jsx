const features = [
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="12" r="3" /><circle cx="5" cy="5" r="2" /><circle cx="19" cy="5" r="2" /><circle cx="5" cy="19" r="2" /><circle cx="19" cy="19" r="2" />
        <path d="M10 10L7 7M14 10l3-3M10 14l-3 3M14 14l3 3" />
      </svg>
    ),
    title: '6-Tier MLM Matrix',
    desc: 'Earn commissions not just from direct referrals, but from their referrals — up to 6 levels deep. Your network grows exponentially while you sleep.',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="5" y="2" width="14" height="20" rx="2" /><path d="M12 18h.01" />
      </svg>
    ),
    title: 'Automated M-Pesa Payouts',
    desc: 'No more waiting for manual payments. Commissions go straight to your M-Pesa via Safaricom B2C, or PayPal for international affiliates.',
  },
  {
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M21 12a9 9 0 11-6.219-8.56" /><path d="M21 3v6h-6" />
      </svg>
    ),
    title: 'Recurring Daily Income',
    desc: 'Unlike one-time sales, our subscription model means you earn commissions every day, week, month, or year — as long as your downline stays active.',
  },
]

const tiers = [
  { level: 'Tier 1', label: 'Direct Referrals', pct: '25%', color: 'from-brand-500 to-brand-600' },
  { level: 'Tier 2', label: 'Level 2 Indirect', pct: '10%', color: 'from-ocean-500 to-ocean-600' },
  { level: 'Tier 3', label: 'Level 3 Indirect', pct: '5%', color: 'from-brand-400 to-ocean-500' },
  { level: 'Tier 4', label: 'Level 4 Indirect', pct: '4%', color: 'from-ocean-400 to-brand-500' },
  { level: 'Tier 5', label: 'Level 5 Indirect', pct: '3%', color: 'from-brand-500 to-ocean-400' },
  { level: 'Tier 6', label: 'Level 6 Indirect', pct: '3%', color: 'from-ocean-500 to-brand-400' },
]

export default function Affiliate() {
  return (
    <section id="affiliate" className="relative py-24">
      <div className="absolute inset-0 grid-glow opacity-50" />
      <div className="container-x relative">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Affiliate Network</span>
          <h2 className="section-title mt-3">Build a network that pays you daily</h2>
          <p className="section-sub">
            Share your referral link, grow your downline, and earn recurring commissions on every
            subscription — automatically deposited to your wallet.
          </p>
        </div>

        <div className="mt-16 grid gap-6 lg:grid-cols-3">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="card card-hover p-7 [animation:fadeUp_0.6s_ease-out_both]"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500/15 text-brand-400">
                {f.icon}
              </div>
              <h3 className="mt-5 text-lg font-bold text-white">{f.title}</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-slate-400">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-16">
          <h3 className="text-center text-xl font-bold text-white">6-Tier Commission Structure</h3>
          <p className="mt-2 text-center text-sm text-slate-400">
            Earn from your entire downline tree — every renewal, every tier.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            {tiers.map((t, i) => (
              <div
                key={t.level}
                className="card card-hover relative overflow-hidden p-5 text-center [animation:fadeUp_0.5s_ease-out_both]"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className={`mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br ${t.color} text-sm font-black text-ink-950`}>
                  {i + 1}
                </div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500">{t.level}</div>
                <div className="mt-1 text-sm text-slate-400">{t.label}</div>
                <div className="mt-3 text-2xl font-extrabold text-brand-400">{t.pct}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
