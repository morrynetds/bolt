export default function Footer() {
  return (
    <footer className="relative border-t border-white/10 bg-ink-950">
      <div className="container-x py-16">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-400 to-ocean-500 font-mono text-sm font-bold text-ink-950">
                M
              </span>
              <span className="text-lg font-extrabold tracking-tight text-white">
                Morry<span className="text-brand-400">Net</span>Pro
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-400">
              Institutional-grade ICT trading tools and a 6-tier affiliate network with automated
              M-Pesa payouts. Trade smart, earn daily.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300">Platform</h4>
            <ul className="mt-4 space-y-2.5 text-sm text-slate-400">
              <li><a href="#tools" className="hover:text-brand-400">Trading Tools</a></li>
              <li><a href="/shop" className="hover:text-brand-400">Shop</a></li>
              <li><a href="#affiliate" className="hover:text-brand-400">Affiliate Network</a></li>
              <li><a href="#pricing" className="hover:text-brand-400">Pricing</a></li>
              <li><a href="#faq" className="hover:text-brand-400">FAQ</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300">Get Started</h4>
            <ul className="mt-4 space-y-2.5 text-sm text-slate-400">
              <li><a href="#signup" className="hover:text-brand-400">Create Account</a></li>
              <li><a href="/login" className="hover:text-brand-400">Log In</a></li>
              <li><a href="/dashboard" className="hover:text-brand-400">Dashboard</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 sm:flex-row">
          <p className="text-xs text-slate-500">
            &copy; {new Date().getFullYear()} MorryNetPro. All rights reserved.
          </p>
          <p className="text-xs text-slate-500">
            Trading involves risk. Past performance does not guarantee future results.
          </p>
        </div>
      </div>
    </footer>
  )
}
