import { Link } from 'react-router-dom'

const products = [
  {
    title: 'Standalone HTML trading dashboard',
    desc: 'A full dashboard experience shipped as a standalone HTML package you can host anywhere.',
  },
  {
    title: 'EAS-compatible indicator bundle',
    desc: 'Indicator files and configuration for export into EAS-ready trading systems.',
  },
  {
    title: 'Trading utility toolkit',
    desc: 'Risk calculators, signal filters, and chart overlays designed for fast decision-making.',
  },
]

export default function ShopSection() {
  return (
    <section id="shop" className="relative py-24">
      <div className="container-x">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow">Shop</span>
          <h2 className="section-title mt-3">Buy standalone systems, indicator packs, and trading tools</h2>
          <p className="section-sub">
            Purchase standalone systems, EAS indicator packs, and trading tools that work with the same ICT workflow used on this site. Shop products are sold alongside subscription access.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <div key={product.title} className="rounded-4xl border border-white/10 bg-ink-900/70 p-6 shadow-xl shadow-black/10">
              <h3 className="text-lg font-semibold text-white">{product.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-400">{product.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link to="/shop" className="btn-primary inline-flex items-center justify-center px-6 py-3 text-sm">
            Visit the Shop
          </Link>
        </div>
      </div>
    </section>
  )
}
