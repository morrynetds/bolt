import { useEffect, useState } from 'react'

const plans = [
  { name: 'Daily', price: 2, period: '/ day', desc: 'Billed every 24 hours', featured: false },
  { name: 'Weekly', price: 10, period: '/ week', desc: 'Billed every 7 days', featured: false },
  { name: 'Monthly', price: 30, period: '/ month', desc: 'Billed every 30 days', featured: true },
  { name: 'Yearly', price: 200, period: '/ year', desc: 'Billed annually', featured: false },
]

function useCountdown(targetIso) {
  const calc = () => {
    if (!targetIso) return null
    const diff = new Date(targetIso).getTime() - Date.now()
    if (diff <= 0) return { d: 0, h: 0, m: 0, s: 0, expired: true }
    const d = Math.floor(diff / 86400000)
    const h = Math.floor((diff % 86400000) / 3600000)
    const m = Math.floor((diff % 3600000) / 60000)
    const s = Math.floor((diff % 60000) / 1000)
    return { d, h, m, s, expired: false }
  }
  const [t, setT] = useState(calc)
  useEffect(() => {
    const id = setInterval(() => setT(calc()), 1000)
    return () => clearInterval(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetIso])
  return t
}

export default function Pricing() {
  const [trialEnd, setTrialEnd] = useState(null)
  const [trialActive, setTrialActive] = useState(false)
  const t = useCountdown(trialEnd)

  useEffect(() => {
    const stored = localStorage.getItem('mn_trial_end')
    if (stored) {
      setTrialEnd(stored)
      setTrialActive(new Date(stored) > new Date())
    }
  }, [])

  const startTrial = () => {
    const end = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    localStorage.setItem('mn_trial_end', end)
    setTrialEnd(end)
    setTrialActive(true)
    document.getElementById('signup')?.scrollIntoView({ behavior: 'smooth' })
  }

  const pad = (n) => String(n).padStart(2, '0')

  return (
    <section id="pricing" className="relative py-24">
      <div className="container-x">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Pricing</span>
          <h2 className="section-title mt-3">Subscription plans for every trader</h2>
          <p className="section-sub">
            MorryNetPro is a subscription service. Every plan unlocks the full ICT trading dashboard
            and the 6-tier affiliate network — where 50% of every sale is shared with our affiliates.
            Start with a 7-day free trial, no card required.
          </p>
        </div>

        {/* Free trial banner */}
        <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-brand-500/30 bg-gradient-to-br from-brand-500/10 to-ocean-500/10 p-6 text-center">
          {trialActive && t && !t.expired ? (
            <>
              <div className="text-sm font-bold uppercase tracking-wider text-brand-300">Your free trial is active</div>
              <div className="mt-4 flex justify-center gap-4 text-white">
                {[
                  { v: t.d, l: 'Days' },
                  { v: t.h, l: 'Hours' },
                  { v: t.m, l: 'Mins' },
                  { v: t.s, l: 'Secs' },
                ].map((u) => (
                  <div key={u.l} className="flex flex-col items-center">
                    <span className="text-3xl font-black tabular-nums">{pad(u.v)}</span>
                    <span className="mt-1 text-[10px] uppercase tracking-wider text-slate-400">{u.l}</span>
                  </div>
                ))}
              </div>
              <p className="mt-4 text-sm text-slate-400">
                Trial ends when the countdown hits zero. Subscribe below to keep full access.
              </p>
            </>
          ) : (
            <>
              <div className="text-sm font-bold uppercase tracking-wider text-brand-300">7-Day Free Trial</div>
              <h3 className="mt-2 text-2xl font-black text-white">Try everything free for a week</h3>
              <p className="mt-2 text-sm text-slate-400">
                Open an account and verify your email to activate your 7-day free trial.
                Full access to trading tools and the affiliate network — no card required.
              </p>
              <button onClick={startTrial} className="btn-primary mt-5">
                Start Free Trial
              </button>
            </>
          )}
        </div>

        <div className="mx-auto mt-16 grid max-w-5xl gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {plans.map((p, i) => (
            <div
              key={p.name}
              className={`card relative flex flex-col p-7 [animation:fadeUp_0.6s_ease-out_both] ${
                p.featured ? 'border-brand-500/60 bg-brand-500/[0.06] shadow-xl shadow-brand-500/10' : 'card-hover'
              }`}
              style={{ animationDelay: `${i * 80}ms` }}
            >
              {p.featured && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand-500 px-4 py-1 text-xs font-bold text-ink-950">
                  Most Popular
                </span>
              )}
              <div className="text-lg font-bold text-white">{p.name} Plan</div>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-black text-white">${p.price}</span>
                <span className="text-sm text-slate-400">{p.period}</span>
              </div>
              <p className="mt-2 text-sm text-slate-500">{p.desc}</p>
              <ul className="mt-6 space-y-3 text-sm text-slate-300">
                {['Full ICT trading dashboard', '6-tier affiliate network', '50% revenue share', 'Automated M-Pesa payouts'].map((f) => (
                  <li key={f} className="flex items-center gap-2.5">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#34d399" strokeWidth="3">
                      <path d="M20 6L9 17l-5-5" />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
              <a
                href="#signup"
                className={`mt-8 ${p.featured ? 'btn-primary' : 'btn-ghost'}`}
              >
                Subscribe {p.name}
              </a>
            </div>
          ))}
        </div>

        <p className="mx-auto mt-10 max-w-2xl text-center text-xs text-slate-500">
          50% of every subscription is shared with the 6-tier affiliate network: 25% Tier 1, 10% Tier 2,
          5% Tier 3, and 10% across Tiers 4-6. Commissions are credited automatically and paid out via M-Pesa.
        </p>
      </div>
    </section>
  )
}
