import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useCart } from '../contexts/CartContext'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const { user, signOut } = useAuth()
  const { items } = useCart()
  const navigate = useNavigate()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const handleSignOut = async () => {
    await signOut()
    navigate('/')
  }

  const links = [
    { label: 'Trading Tools', href: '#tools' },
    { label: 'Shop', href: '/shop' },
    { label: 'Affiliate', href: '#affiliate' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'FAQ', href: '#faq' },
  ]

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-ink-950/85 backdrop-blur-xl border-b border-white/10' : 'bg-transparent'
      }`}
    >
      <nav className="container-x flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5" onClick={() => setOpen(false)}>
          <img src="/logo.png" alt="MorryNetPro" className="h-9 w-9 rounded-xl object-contain" />
          <span className="text-lg font-extrabold tracking-tight text-white">
            Morry<span className="text-brand-400">Net</span>Pro
          </span>
        </Link>

        <div className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium text-slate-300 transition-colors hover:text-brand-400"
            >
              {l.label}
            </a>
          ))}
        </div>

        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <>
              <Link to="/dashboard" className="btn-ghost text-sm">
                Dashboard
              </Link>
              <Link to="/checkout" className="btn-ghost text-sm">
                Cart ({items.length})
              </Link>
              <button onClick={handleSignOut} className="btn-primary text-sm">
                Sign Out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-sm font-semibold text-slate-300 hover:text-white">
                Log In
              </Link>
              <a href="#signup" className="btn-primary text-sm">
                Get Started
              </a>
            </>
          )}
        </div>

        <button
          className="flex h-10 w-10 items-center justify-center rounded-lg text-white md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Menu"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {open ? <path d="M18 6L6 18M6 6l12 12" /> : <path d="M3 6h18M3 12h18M3 18h18" />}
          </svg>
        </button>
      </nav>

      {open && (
        <div className="border-t border-white/10 bg-ink-950/95 px-5 py-4 backdrop-blur-xl md:hidden">
          <div className="flex flex-col gap-3">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm font-medium text-slate-300 hover:text-brand-400"
                onClick={() => setOpen(false)}
              >
                {l.label}
              </a>
            ))}
            <div className="mt-2 flex flex-col gap-2">
              {user ? (
                <>
                  <Link to="/dashboard" className="btn-ghost text-sm" onClick={() => setOpen(false)}>
                    Dashboard
                  </Link>
                  <button onClick={handleSignOut} className="btn-primary text-sm">
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" className="btn-ghost text-sm" onClick={() => setOpen(false)}>
                    Log In
                  </Link>
                  <a href="#signup" className="btn-primary text-sm" onClick={() => setOpen(false)}>
                    Get Started
                  </a>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
