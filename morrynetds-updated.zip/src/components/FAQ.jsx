import { useState } from 'react'

const faqs = [
  {
    q: 'How does the 6-tier commission system work?',
    a: 'When you refer someone (Tier 1), you earn a commission on every subscription they purchase. But you also earn smaller commissions when they refer someone (Tier 2), and so on up to 6 levels deep. Your earning potential grows exponentially as your network expands. All commissions are calculated and deposited automatically.',
  },
  {
    q: 'How do I withdraw my earnings to M-Pesa?',
    a: 'Log into your Member Dashboard, navigate to the Withdrawals tab, enter the amount you\'d like to withdraw, and confirm your M-Pesa phone number. Our system uses Safaricom\'s B2C API to send the funds directly to your phone within minutes. You can also choose PayPal as your payout method.',
  },
  {
    q: 'What payment methods are accepted?',
    a: 'We accept M-Pesa (via STK Push — you\'ll receive a prompt on your phone to enter your PIN) and PayPal (for international users). All subscription renewals are billed automatically using your chosen payment method.',
  },
  {
    q: 'Can I upgrade or downgrade my subscription?',
    a: 'Absolutely. You can switch between Daily ($2), Weekly ($10), Monthly ($30), and Yearly ($200) plans at any time from your account dashboard. Changes take effect at the start of your next billing cycle.',
  },
  {
    q: 'Is there a minimum withdrawal amount?',
    a: 'Yes, the minimum withdrawal amount is $1.00 to cover M-Pesa transaction fees. Once your wallet balance reaches this threshold, you can request a payout at any time. There are no maximum limits.',
  },
  {
    q: 'Do I earn commissions on subscription renewals?',
    a: 'Yes! This is the most powerful part of the system. You don\'t just earn a one-time commission when someone signs up — you earn a commission every single time their subscription renews. If your Tier 1 referral is on the $2 Daily plan, you earn a commission every single day for as long as they remain subscribed.',
  },
]

export default function FAQ() {
  const [open, setOpen] = useState(null)

  return (
    <section id="faq" className="relative py-24">
      <div className="container-x">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">FAQ</span>
          <h2 className="section-title mt-3">Frequently asked questions</h2>
          <p className="section-sub">Everything you need to know before getting started.</p>
        </div>

        <div className="mx-auto mt-12 max-w-3xl space-y-3">
          {faqs.map((f, i) => (
            <div
              key={i}
              className={`card overflow-hidden transition-all ${open === i ? 'border-brand-500/40' : ''}`}
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between px-6 py-5 text-left"
              >
                <span className="text-base font-semibold text-white">{f.q}</span>
                <svg
                  width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
                  className={`flex-shrink-0 text-slate-400 transition-transform duration-300 ${open === i ? 'rotate-180 text-brand-400' : ''}`}
                >
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>
              <div
                className={`grid transition-all duration-300 ${open === i ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
              >
                <div className="overflow-hidden">
                  <p className="px-6 pb-5 text-sm leading-relaxed text-slate-400">{f.a}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
