import { useEffect, useState } from 'react'

const tickers = [
  { sym: 'EURUSD', price: '1.0842', chg: '+0.32%', up: true },
  { sym: 'GBPJPY', price: '189.45', chg: '-0.18%', up: false },
  { sym: 'XAUUSD', price: '2,341.50', chg: '+0.74%', up: true },
  { sym: 'BTCUSD', price: '67,890', chg: '+1.20%', up: true },
  { sym: 'US30', price: '39,120', chg: '-0.05%', up: false },
  { sym: 'NAS100', price: '18,240', chg: '+0.45%', up: true },
]

function MiniChart() {
  const [bars, setBars] = useState(() => {
    let v = 50
    return Array.from({ length: 40 }, () => {
      v += (Math.random() - 0.48) * 6
      v = Math.max(20, Math.min(80, v))
      return v
    })
  })

  useEffect(() => {
    const id = setInterval(() => {
      setBars((prev) => {
        const next = [...prev.slice(1)]
        const last = prev[prev.length - 1]
        const nv = Math.max(20, Math.min(80, last + (Math.random() - 0.48) * 6))
        next.push(nv)
        return next
      })
    }, 1200)
    return () => clearInterval(id)
  }, [])

  const w = 520
  const h = 200
  const step = w / (bars.length - 1)
  const path = bars.map((v, i) => `${i === 0 ? 'M' : 'L'} ${i * step} ${h - v * 2}`).join(' ')
  const area = `${path} L ${w} ${h} L 0 ${h} Z`

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-full w-full">
      <defs>
        <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#chartFill)" />
      <path d={path} fill="none" stroke="#34d399" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      {bars.length > 0 && (
        <circle cx={(bars.length - 1) * step} cy={h - bars[bars.length - 1] * 2} r="4" fill="#34d399">
          <animate attributeName="opacity" values="1;0.3;1" dur="1.5s" repeatCount="indefinite" />
        </circle>
      )}
    </svg>
  )
}

export default function Hero() {
  return (
    <section className="relative overflow-hidden pt-28 pb-20 sm:pt-36">
      <div className="absolute inset-0 grid-glow" />
      <div className="absolute inset-0 grid-lines opacity-40" />

      <div className="container-x relative">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-brand-500/30 bg-brand-500/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-brand-300">
              <span className="h-2 w-2 animate-pulse-soft rounded-full bg-brand-400" />
              Subscription Service · 50% Affiliate Revenue Share
            </span>
            <h1 className="mt-6 text-4xl font-black leading-[1.05] tracking-tight text-white sm:text-5xl lg:text-6xl">
              Trade with <span className="text-gradient">institutional precision</span>. Earn <span className="text-gradient">daily recurring income</span>.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-slate-400">
              MorryNetPro is a subscription-based ICT trading platform. Shop standalone HTML systems, indicator packs, and companion tools while earning affiliate revenue via our 6-tier network. Start free for 7 days, no card required.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a href="#signup" className="btn-primary">
                Start 7-Day Free Trial
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M5 12h14M13 5l7 7-7 7" />
                </svg>
              </a>
              <a href="#tools" className="btn-ghost">
                Explore Trading Tools
              </a>
            </div>
            <div className="mt-12 flex gap-10">
              {[
                { num: '50%', label: 'Revenue Shared' },
                { num: '7 days', label: 'Free Trial' },
                { num: '$2', label: 'Starting Daily' },
              ].map((s) => (
                <div key={s.label}>
                  <div className="text-2xl font-extrabold text-white">{s.num}</div>
                  <div className="mt-1 text-xs text-slate-500">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="animate-fade-up [animation-delay:200ms]">
            <div className="card relative overflow-hidden p-1">
              <div className="rounded-xl bg-ink-900/80 p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="h-3 w-3 rounded-full bg-danger-500" />
                    <span className="h-3 w-3 rounded-full bg-gold-400" />
                    <span className="h-3 w-3 rounded-full bg-brand-500" />
                  </div>
                  <span className="font-mono text-xs text-slate-500">morrynetpro.io/dashboard</span>
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <div>
                    <div className="text-sm text-slate-400">EUR/USD</div>
                    <div className="font-mono text-2xl font-bold text-white">1.0842</div>
                  </div>
                  <div className="rounded-lg bg-brand-500/15 px-3 py-1.5 text-sm font-bold text-brand-400">
                    +0.32%
                  </div>
                </div>

                <div className="mt-4 h-48">
                  <MiniChart />
                </div>

                <div className="mt-4 grid grid-cols-3 gap-3">
                  {[
                    { label: 'Consensus', val: 'Bullish', color: 'text-brand-400' },
                    { label: 'Liquidity', val: 'Buy Side', color: 'text-ocean-400' },
                    { label: 'R/R', val: '1:3.5', color: 'text-gold-400' },
                  ].map((b) => (
                    <div key={b.label} className="rounded-lg border border-white/10 bg-ink-800/50 p-3 text-center">
                      <div className="text-[10px] uppercase text-slate-500">{b.label}</div>
                      <div className={`mt-1 text-sm font-bold ${b.color}`}>{b.val}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-4 overflow-hidden rounded-xl border border-white/10 bg-ink-900/60">
              <div className="flex animate-ticker gap-6 py-3">
                {[...tickers, ...tickers].map((t, i) => (
                  <div key={i} className="flex items-center gap-2 whitespace-nowrap px-2">
                    <span className="font-mono text-xs font-bold text-slate-300">{t.sym}</span>
                    <span className="font-mono text-xs text-slate-400">{t.price}</span>
                    <span className={`font-mono text-xs font-bold ${t.up ? 'text-brand-400' : 'text-danger-400'}`}>
                      {t.chg}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
