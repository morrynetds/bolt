import { Routes, Route } from 'react-router-dom'
import { AuthProvider } from './lib/auth'
import { CartProvider } from './contexts/CartContext'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import TradingTools from './components/TradingTools'
import ShopSection from './components/ShopSection'
import Affiliate from './components/Affiliate'
import HowItWorks from './components/HowItWorks'
import Pricing from './components/Pricing'
import Signup from './components/Signup'
import FAQ from './components/FAQ'
import Footer from './components/Footer'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Shop from './pages/Shop'
import ProductDetail from './pages/ProductDetail'
import Checkout from './pages/Checkout'

function Landing() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <TradingTools />
        <ShopSection />
        <Affiliate />
        <HowItWorks />
        <Pricing />
        <Signup />
        <FAQ />
      </main>
      <Footer />
    </>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/shop/:slug" element={<ProductDetail />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </CartProvider>
    </AuthProvider>
  )
}
