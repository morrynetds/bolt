import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'

export default function Dashboard() {
  const { user, loading: authLoading, signOut } = useAuth()
  const navigate = useNavigate()

  const [affiliate, setAffiliate] = useState(null)
  const [wallet, setWallet] = useState(null)
  const [commissions, setCommissions] = useState([])
  const [tiers, setTiers] = useState([0, 0, 0, 0, 0, 0])
  const [tab, setTab] = useState('overview')
  const [loading, setLoading] = useState(true)
  const [fetchError, setFetchError] = useState('')
  const [refLink, setRefLink] = useState('')
  const [copied, setCopied] = useState(false)
  const [withdrawAmount, setWithdrawAmount] = useState('')
  const [withdrawPhone, setWithdrawPhone] = useState('')
  const [withdrawMsg, setWithdrawMsg] = useState(null)

  // Trading dashboard (gated, served via edge function as a blob URL)
  const [tradingUrl, setTradingUrl] = useState(null)
  const [tradingState, setTradingState] = useState('idle') // idle | loading | ready | locked | error
  const [tradingError, setTradingError] = useState('')
  const [isFullscreen, setIsFullscreen] = useState(false)

  useEffect(() => {
    if (tab !== 'trading' || tradingState !== 'idle') return
    setTradingState('loading')
    setTradingError('')
    ;(async () => {
      try {
        const { data: sessionData } = await supabase.auth.getSession()
        const token = sessionData?.session?.access_token
        if (!token) {
          setTradingState('locked')
          setTradingError('You must be signed in.')
          return
        }
        const fnUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/trading-dashboard`
        const res = await fetch(fnUrl, {
          headers: {
            Authorization: `Bearer ${token}`,
            apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
        })
        if (res.status === 403) {
          setTradingState('locked')
          setTradingError('An active subscription is required to access the trading tools.')
          return
        }
        if (!res.ok) {
          setTradingState('error')
          setTradingError(`Failed to load trading dashboard (${res.status}).`)
          return
        }
        const html = await res.text()
        const blob = new Blob([html], { type: 'text/html' })
        setTradingUrl(URL.createObjectURL(blob))
        setTradingState('ready')
      } catch (err) {
        setTradingState('error')
        setTradingError(err.message || 'Failed to load trading dashboard.')
      }
    })()
  }, [tab, tradingState])

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login')
    }
  }, [authLoading, user, navigate])

  useEffect(() => {
    if (!user) return

    const fetchData = async () => {
      setLoading(true)
      try {
        const { data: aff } = await supabase
          .from('affiliates')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle()

        if (!aff) {
          setLoading(false)
          return
        }

        setAffiliate(aff)
        setRefLink(`${window.location.origin}/?ref=${user.id}`)

        const { data: w } = await supabase
          .from('wallets')
          .select('*')
          .eq('affiliate_id', user.id)
          .maybeSingle()
        setWallet(w)

        const { data: comms } = await supabase
          .from('commissions')
          .select('*')
          .eq('affiliate_id', user.id)
          .gt('level', 0)
          .order('date', { ascending: false })
          .limit(10)
        setCommissions(comms || [])

        // Calculate downline tiers
        if (aff.tree_path) {
          const myDepth = aff.tree_path.split('-').filter(Boolean).length
          const { data: downlines } = await supabase
            .from('affiliates')
            .select('tree_path')
            .like('tree_path', `${aff.tree_path}%`)

          const tierCounts = [0, 0, 0, 0, 0, 0]
          if (downlines) {
            downlines.forEach((d) => {
              if (d.tree_path === aff.tree_path) return
              const dDepth = d.tree_path.split('-').filter(Boolean).length
              const rel = dDepth - myDepth
              if (rel >= 1 && rel <= 6) tierCounts[rel - 1]++
            })
          }
          setTiers(tierCounts)
        }

        setWithdrawPhone(aff.payout_details || aff.phone || '')
      } catch (err) {
        const message = err?.message || String(err)
        if (message.includes("Could not find the table 'public.affiliates'")) {
          setFetchError('The backend database schema is not initialized. Please deploy Supabase migrations or contact support.')
        } else {
          setFetchError('Failed to load your affiliate dashboard. Please refresh or contact support.')
        }
        console.error('Dashboard fetch error:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [user])

  const handleCopy = () => {
    navigator.clipboard.writeText(refLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleWithdraw = async (e) => {
    e.preventDefault()
    setWithdrawMsg(null)

    const amount = parseFloat(withdrawAmount)
    if (!amount || amount <= 0) {
      setWithdrawMsg({ type: 'error', text: 'Enter a valid amount.' })
      return
    }

    const balance = wallet?.current_balance || 0
    if (amount > balance) {
      setWithdrawMsg({ type: 'error', text: 'Insufficient wallet balance.' })
      return
    }

    try {
      const { error: wError } = await supabase.from('withdrawals').insert({
        affiliate_id: user.id,
        amount,
        phone: withdrawPhone,
        status: 'pending',
      })

      if (wError) throw wError

      const { error: logError } = await supabase.from('commissions').insert({
        affiliate_id: user.id,
        transaction_id: '0',
        level: 0,
        amount: -amount,
        status: 'pending',
      })

      if (logError) throw logError

      const newBalance = balance - amount
      const { error: walletError } = await supabase
        .from('wallets')
        .update({ current_balance: newBalance, total_withdrawn: (wallet?.total_withdrawn || 0) + amount })
        .eq('affiliate_id', user.id)

      if (walletError) throw walletError

      setWallet({ ...wallet, current_balance: newBalance, total_withdrawn: (wallet?.total_withdrawn || 0) + amount })
      setWithdrawAmount('')
      setWithdrawMsg({ type: 'success', text: 'Withdrawal request submitted! Funds will reflect in your M-Pesa shortly.' })
    } catch (err) {
      setWithdrawMsg({ type: 'error', text: err.message || 'Withdrawal failed. Try again.' })
    }
  }

  if (authLoading || loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink-950">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
      </div>
    )
  }

  if (fetchError) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-ink-950 px-5 text-center">
        <div className="rounded-3xl border border-danger-500/20 bg-danger-500/10 px-8 py-7 text-left text-sm text-danger-100 max-w-xl">
          <p className="font-semibold text-white">Backend schema unavailable</p>
          <p className="mt-3 text-slate-300">{fetchError}</p>
        </div>
        <Link to="/" className="btn-primary">Back to homepage</Link>
      </div>
    )
  }

  if (!affiliate) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-ink-950 px-5 text-center">
        <p className="text-lg text-slate-300">You are not registered as a member yet.</p>
        <Link to="/#signup" className="btn-primary">Create Member Account</Link>
      </div>
    )
  }

  const balance = wallet?.current_balance || 0
  const withdrawn = wallet?.total_withdrawn || 0
  const total = balance + withdrawn

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'trading', label: 'Trading Tools' },
    { id: 'downline', label: 'My Downline' },
    { id: 'history', label: 'Commission History' },
    { id: 'withdraw', label: 'Withdrawals' },
  ]

  return (
    <div className="min-h-screen bg-ink-950 pt-20">
      <div className="container-x py-10">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-extrabold text-white">Member Dashboard</h1>
          <div className="flex items-center gap-3">
            <Link to="/" className="btn-ghost text-sm">
              Back to Site
            </Link>
            <button onClick={() => signOut().then(() => navigate('/'))} className="btn-ghost text-sm">
              Sign Out
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-8 flex gap-1 overflow-x-auto border-b border-white/10 no-scrollbar">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`whitespace-nowrap border-b-2 px-5 py-3 text-sm font-semibold transition-colors ${
                tab === t.id ? 'border-brand-500 text-brand-400' : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Overview */}
        {tab === 'overview' && (
          <div className="mt-8 space-y-8">
            <div className="grid gap-5 sm:grid-cols-3">
              {[
                { label: 'Total Earnings', value: `$${total.toFixed(2)}`, color: 'text-white' },
                { label: 'Wallet Balance', value: `$${balance.toFixed(2)}`, color: 'text-brand-400' },
                { label: 'Total Withdrawn', value: `$${withdrawn.toFixed(2)}`, color: 'text-ocean-400' },
              ].map((s) => (
                <div key={s.label} className="card p-6">
                  <div className="text-sm text-slate-400">{s.label}</div>
                  <div className={`mt-2 text-3xl font-extrabold ${s.color}`}>{s.value}</div>
                </div>
              ))}
            </div>

            <div>
              <h3 className="text-lg font-bold text-white">Your Unique Referral Link</h3>
              <p className="mt-2 text-sm text-slate-400">
                Share this link to earn commissions on daily, weekly, monthly, and yearly subscriptions.
              </p>
              <div className="mt-4 flex gap-3">
                <input readOnly value={refLink} className="input font-mono text-sm" />
                <button onClick={handleCopy} className="btn-primary whitespace-nowrap">
                  {copied ? 'Copied!' : 'Copy Link'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Trading Tools — gated, served via edge function */}
        {tab === 'trading' && (
          <div className="mt-8">
            <h3 className="text-lg font-bold text-white">ICT Trading Dashboard</h3>
            <p className="mt-2 text-sm text-slate-400">
              Multi-timeframe liquidity analysis, consensus matrix, and smart signals — live in your browser.
              Access is restricted to active subscribers.
            </p>

            {tradingState === 'loading' && (
              <div className="mt-6 flex items-center gap-3 rounded-2xl border border-white/10 bg-ink-900/60 px-5 py-4 text-sm text-slate-300">
                <span className="h-3 w-3 animate-pulse-soft rounded-full bg-brand-400" />
                Loading trading dashboard…
              </div>
            )}

            {tradingState === 'locked' && (
              <div className="mt-6 rounded-2xl border border-gold-400/30 bg-gold-400/10 px-5 py-6">
                <div className="flex items-start gap-3">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mt-0.5 text-gold-400">
                    <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0110 0v4" />
                  </svg>
                  <div>
                    <h4 className="text-base font-bold text-white">Subscription required</h4>
                    <p className="mt-1 text-sm text-slate-300">{tradingError || 'An active subscription is required to access the trading tools.'}</p>
                    <Link to="/#pricing" className="btn-primary mt-4 text-sm">View Plans</Link>
                  </div>
                </div>
              </div>
            )}

            {tradingState === 'error' && (
              <div className="mt-6 rounded-2xl border border-danger-500/30 bg-danger-500/10 px-5 py-4 text-sm text-danger-400">
                {tradingError || 'Failed to load trading dashboard.'}
              </div>
            )}

            {tradingState === 'ready' && tradingUrl && (
              <div className="mt-6">
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-xs text-slate-500">Subscribed · Live trading dashboard</p>
                  <button
                    onClick={() => setIsFullscreen(true)}
                    className="btn-ghost text-xs"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M8 3H5a2 2 0 00-2 2v3M16 3h3a2 2 0 012 2v3M8 21H5a2 2 0 01-2-2v-3M16 21h3a2 2 0 002-2v-3" />
                    </svg>
                    Fullscreen
                  </button>
                </div>
                <div className="overflow-hidden rounded-2xl border border-white/10 bg-ink-900/60">
                  <iframe
                    src={tradingUrl}
                    title="ICT Trading Dashboard"
                    className="h-[80vh] w-full"
                    sandbox="allow-scripts allow-same-origin"
                    style={{ border: 'none' }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Downline */}
        {tab === 'downline' && (
          <div className="mt-8">
            <h3 className="text-lg font-bold text-white">6-Tier Network Matrix</h3>
            <p className="mt-2 text-sm text-slate-400">Active affiliates in your downline tree.</p>
            <div className="mt-6 overflow-hidden rounded-2xl border border-white/10">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-ink-800/50 text-sm text-slate-400">
                    <th className="px-6 py-4 font-semibold">Tier Level</th>
                    <th className="px-6 py-4 font-semibold">Description</th>
                    <th className="px-6 py-4 text-right font-semibold">Active Affiliates</th>
                  </tr>
                </thead>
                <tbody>
                  {tiers.map((count, i) => (
                    <tr key={i} className="border-t border-white/5">
                      <td className="px-6 py-4 font-bold text-white">Tier {i + 1}</td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {i === 0 ? 'Direct Referrals' : `Level ${i + 1} Indirect Referrals`}
                      </td>
                      <td className="px-6 py-4 text-right text-lg font-bold text-brand-400">{count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* History */}
        {tab === 'history' && (
          <div className="mt-8">
            <h3 className="text-lg font-bold text-white">Commission Ledger</h3>
            <div className="mt-6 overflow-hidden rounded-2xl border border-white/10">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-ink-800/50 text-sm text-slate-400">
                    <th className="px-6 py-4 font-semibold">Date</th>
                    <th className="px-6 py-4 font-semibold">Order / Renewal ID</th>
                    <th className="px-6 py-4 font-semibold">Tier Level</th>
                    <th className="px-6 py-4 text-right font-semibold">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {commissions.length === 0 ? (
                    <tr>
                      <td colSpan="4" className="px-6 py-12 text-center text-slate-500">
                        No commissions earned yet.
                      </td>
                    </tr>
                  ) : (
                    commissions.map((c) => (
                      <tr key={c.id} className="border-t border-white/5">
                        <td className="px-6 py-4 text-sm text-slate-300">
                          {new Date(c.date).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-400">#{c.transaction_id}</td>
                        <td className="px-6 py-4 text-sm text-slate-400">Level {c.level}</td>
                        <td className="px-6 py-4 text-right font-semibold text-brand-400">
                          ${Math.abs(c.amount).toFixed(2)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Withdrawals */}
        {tab === 'withdraw' && (
          <div className="mt-8 max-w-md">
            <h3 className="text-lg font-bold text-white">Request M-Pesa Payout</h3>
            <p className="mt-2 text-sm text-slate-400">
              Available Balance: <span className="font-bold text-brand-400">${balance.toFixed(2)}</span>
            </p>

            {withdrawMsg && (
              <div className={`mt-4 rounded-xl border px-4 py-3 text-sm ${
                withdrawMsg.type === 'success'
                  ? 'border-brand-500/30 bg-brand-500/10 text-brand-400'
                  : 'border-danger-500/30 bg-danger-500/10 text-danger-400'
              }`}>
                {withdrawMsg.text}
              </div>
            )}

            {balance <= 0 ? (
              <div className="mt-4 rounded-xl border border-danger-500/30 bg-danger-500/10 px-4 py-3 text-sm text-danger-400">
                You need a positive balance to request a withdrawal.
              </div>
            ) : (
              <form onSubmit={handleWithdraw} className="mt-6 space-y-4">
                <div>
                  <label className="label">Withdrawal Amount ($)</label>
                  <input
                    type="number" step="0.01" min="1" max={balance}
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="input" required
                  />
                </div>
                <div>
                  <label className="label">M-Pesa Phone Number</label>
                  <input
                    type="tel" value={withdrawPhone}
                    onChange={(e) => setWithdrawPhone(e.target.value)}
                    className="input" placeholder="0712345678" required
                  />
                </div>
                <button type="submit" className="btn-primary w-full">Send to M-Pesa</button>
              </form>
            )}
          </div>
        )}
      </div>

      {/* Fullscreen trading overlay */}
      {isFullscreen && tradingUrl && (
        <div className="fixed inset-0 z-[100] bg-ink-950">
          <div className="absolute right-4 top-4 z-10 flex items-center gap-3">
            <a
              href={tradingUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost text-xs"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" />
              </svg>
              Open in new tab
            </a>
            <button
              onClick={() => setIsFullscreen(false)}
              className="btn-primary text-xs"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M8 3v3a2 2 0 01-2 2H3M21 8h-3a2 2 0 01-2-2V3M3 16h3a2 2 0 012 2v3M16 21v-3a2 2 0 012-2h3" />
              </svg>
              Exit Fullscreen
            </button>
          </div>
          <iframe
            src={tradingUrl}
            title="ICT Trading Dashboard — Fullscreen"
            className="h-full w-full"
            sandbox="allow-scripts allow-same-origin"
            style={{ border: 'none' }}
          />
        </div>
      )}
    </div>
  )
}
