import { Link, useNavigate, useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { getProductBySlug, formatCurrency } from '../lib/shopProducts'
import { useCart } from '../contexts/CartContext'

export default function ProductDetail() {
  const { slug } = useParams()
  const product = getProductBySlug(slug)
  const navigate = useNavigate()
  const { addItem } = useCart()
  const [message, setMessage] = useState('')

  useEffect(() => {
    if (!product) {
      navigate('/shop', { replace: true })
    }
  }, [navigate, product])

  if (!product) return null

  const handleAddToCart = () => {
    addItem(product)
    setMessage('Added to cart. Proceed to checkout when ready.')
  }

  return (
    <div className="min-h-screen bg-ink-950 py-24">
      <div className="container-x">
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="eyebrow">Product details</p>
            <h1 className="mt-3 text-4xl font-extrabold text-white">{product.title}</h1>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-400">{product.detailedDescription}</p>
          </div>
          <div className="rounded-3xl bg-ink-900/70 border border-white/10 px-5 py-4 text-right">
            <div className="text-xs uppercase tracking-[0.3em] text-slate-500">Price</div>
            <div className="mt-2 text-3xl font-bold text-brand-300">{formatCurrency(product.price, product.currency)}</div>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1.4fr_0.8fr]">
          <div className="space-y-8">
            <section className="rounded-[32px] border border-white/10 bg-ink-900/70 p-8">
              <h2 className="text-xl font-semibold text-white">Key features</h2>
              <ul className="mt-5 space-y-4 text-sm text-slate-400">
                {product.features.map((feature) => (
                  <li key={feature} className="flex gap-3">
                    <span className="mt-1 h-2.5 w-2.5 rounded-full bg-brand-400" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </section>

            <section className="rounded-[32px] border border-white/10 bg-ink-900/70 p-8">
              <h2 className="text-xl font-semibold text-white">Screenshots & preview</h2>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                {product.screenshotCaptions.map((caption, index) => (
                  <div key={caption} className="rounded-3xl bg-slate-950/60 p-4">
                    <div className="h-40 rounded-3xl bg-gradient-to-br from-brand-500/10 to-ocean-500/10" />
                    <p className="mt-4 text-sm text-slate-400">{caption}</p>
                  </div>
                ))}
              </div>
              <div className="mt-6 flex flex-wrap gap-3">
                <a
                  href={product.demoPath}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-ghost rounded-full px-5 py-3 text-sm"
                >
                  Open demo
                </a>
                <Link to="/shop" className="btn-ghost rounded-full px-5 py-3 text-sm">
                  Back to catalog
                </Link>
              </div>
            </section>
          </div>

          <aside className="space-y-6">
            <div className="rounded-[32px] border border-white/10 bg-ink-900/70 p-8">
              <h2 className="text-xl font-semibold text-white">License</h2>
              <p className="mt-4 text-sm leading-7 text-slate-400">{product.licenseTerms}</p>
            </div>

            <div className="rounded-[32px] border border-white/10 bg-ink-900/70 p-8">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm uppercase tracking-[0.24em] text-slate-500">Price</p>
                  <p className="mt-2 text-3xl font-bold text-brand-300">{formatCurrency(product.price, product.currency)}</p>
                </div>
                <button onClick={handleAddToCart} className="btn-primary rounded-full px-5 py-3 text-sm">
                  Add to cart
                </button>
              </div>
              {message && <p className="mt-5 text-sm text-slate-300">{message}</p>}
            </div>
          </aside>
        </div>
      </div>
    </div>
  )
}
