import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase, isSupabaseConfigured } from '../lib/supabase'
import { useAuth } from '../lib/auth'

export default function Login() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (user) {
    navigate('/dashboard')
    return null
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) throw error
      navigate('/dashboard')
    } catch (err) {
      setError(err.message || 'Login failed. Check your credentials.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-ink-950 px-5 pt-20">
      <div className="absolute inset-0 grid-glow" />
      <div className="absolute inset-0 grid-lines opacity-30" />

      <div className="relative w-full max-w-md">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center gap-2.5">
            <img src="/logo.png" alt="MorryNetPro" className="h-9 w-9 rounded-xl object-contain" />
            <span className="text-lg font-extrabold tracking-tight text-white">
              Morry<span className="text-brand-400">Net</span>Pro
            </span>
          </Link>
          <h1 className="mt-8 text-2xl font-extrabold text-white">Welcome back</h1>
          <p className="mt-2 text-sm text-slate-400">Log in to access your member dashboard.</p>
        </div>

        {!isSupabaseConfigured && (
          <div className="mt-6 rounded-xl border border-gold-400/30 bg-gold-400/10 px-4 py-3 text-sm text-gold-400">
            Login is unavailable right now: the backend is not configured.
          </div>
        )}

        {error && (
          <div className="mt-6 rounded-xl border border-danger-500/30 bg-danger-500/10 px-4 py-3 text-sm text-danger-400">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="card mt-6 space-y-4 p-7">
          <div>
            <label className="label" htmlFor="email">Email Address</label>
            <input
              id="email" name="email" type="email" required
              value={email} onChange={(e) => setEmail(e.target.value)}
              className="input" placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input
              id="password" name="password" type="password" required
              value={password} onChange={(e) => setPassword(e.target.value)}
              className="input" placeholder="Your password"
            />
          </div>
          <button type="submit" disabled={loading || !isSupabaseConfigured} className="btn-primary w-full">
            {loading ? 'Signing In...' : 'Log In'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-400">
          Don't have an account?{' '}
          <Link to="/#signup" className="font-semibold text-brand-400 hover:text-brand-300">
            Sign up free
          </Link>
        </p>
      </div>
    </div>
  )
}
