import { useEffect, useMemo } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { products, formatCurrency } from '../lib/shopProducts'
import { useCart } from '../contexts/CartContext'
import ShopHeader from '../components/ShopHeader'

export default function Shop() {
  const { addItem, items } = useCart()
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => {
    const params = new URLSearchParams(location.search)
    const ref = params.get('ref')
    if (ref) {
      window.localStorage.setItem('affiliate_ref', ref)
    }
  }, [location.search])

  const productCards = useMemo(
    () =>
      products.map((product) => (
        <article key={product.slug} className="rounded-[32px] border border-white/10 bg-ink-950/80 p-7 shadow-xl shadow-black/20">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-bold text-white">{product.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-slate-400">{product.shortDescription}</p>
            </div>
            <div className="rounded-full bg-slate-900/90 px-4 py-2 text-sm font-semibold text-brand-300">
              {formatCurrency(product.price, product.currency)}
            </div>
          </div>

          <div className="mt-6 grid gap-3 text-sm text-slate-400">
            {product.features.map((feature) => (
              <div key={feature} className="flex items-start gap-3">
                <span className="mt-1 h-2.5 w-2.5 rounded-full bg-brand-400" />
                <span>{feature}</span>
              </div>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link to={`/shop/${product.slug}`} className="btn-primary rounded-full px-5 py-3 text-sm">
              View details
            </Link>
            <button
              type="button"
              onClick={() => addItem(product)}
              className="btn-ghost rounded-full px-5 py-3 text-sm"
            >
              Add to cart
            </button>
            <button
              type="button"
              onClick={() => {
                addItem(product)
                navigate('/checkout')
              }}
              className="btn-primary rounded-full border border-white/10 bg-brand-500 px-5 py-3 text-sm"
            >
              Buy now
            </button>
          </div>
        </article>
      )),
    [addItem, navigate],
  )

  return (
    <div className="bg-ink-950">
      <ShopHeader />
      <main className="container-x py-20">
        <section id="products">
          <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <span className="eyebrow">Product Catalog</span>
              <h1 className="mt-3 text-4xl font-extrabold text-white sm:text-5xl">Standalone systems and shop-ready tool bundles</h1>
              <p className="mt-4 max-w-3xl text-base leading-8 text-slate-400">
                Purchase standalone HTML trading dashboards, EAS indicator packs, and utility suites with one-user licensing and affiliate bonus tracking.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link to="/checkout" className="btn-primary rounded-full px-5 py-3 text-sm">
                View cart ({items.length})
              </Link>
            </div>
          </div>

          <div className="grid gap-6 xl:grid-cols-3">{productCards}</div>
        </section>

        <section className="mt-20 rounded-[32px] border border-white/10 bg-ink-900/70 p-10">
          <h2 className="text-2xl font-bold text-white">How purchases work</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            <div className="rounded-3xl bg-white/5 p-6">
              <h3 className="font-semibold text-white">One license per user</h3>
              <p className="mt-3 text-sm text-slate-400">
                Each purchase includes a single-user license key attached to the product and your email address.
              </p>
            </div>
            <div className="rounded-3xl bg-white/5 p-6">
              <h3 className="font-semibold text-white">Affiliate credit bonus</h3>
              <p className="mt-3 text-sm text-slate-400">
                Referrals on shop purchases earn affiliate bonus credit when a valid affiliate id is supplied.
              </p>
            </div>
            <div className="rounded-3xl bg-white/5 p-6">
              <h3 className="font-semibold text-white">Flexible checkout</h3>
              <p className="mt-3 text-sm text-slate-400">
                Choose Stripe, PayPal, or M-Pesa during checkout. Bundles and multiple items are supported.
              </p>
            </div>
          </div>
        </section>

        <section className="mt-20 rounded-[32px] border border-white/10 bg-ink-900/70 p-10 text-center">
          <h2 className="text-2xl font-bold text-white">Need a custom bundle?</h2>
          <p className="mt-3 text-sm leading-relaxed text-slate-400">
            Send us an inquiry and we can package your own dashboard, HTML system, or indicator toolkit to match your trading workflow.
          </p>
          <a
            href="mailto:sales@morrynetpro.io?subject=Custom%20Trading%20System%20Request"
            className="btn-primary mt-6 inline-flex items-center justify-center px-6 py-3 text-sm"
          >
            Request a custom bundle
          </a>
        </section>
      </main>
    </div>
  )
}
