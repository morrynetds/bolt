import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useCart } from '../contexts/CartContext'
import { formatCurrency } from '../lib/shopProducts'

const paymentMethods = [
  { id: 'stripe', label: 'Stripe' },
  { id: 'paypal', label: 'PayPal' },
  { id: 'mpesa', label: 'M-Pesa' },
]

export default function Checkout() {
  const { items, total, updateQuantity, removeItem, clearCart } = useCart()
  const [paymentMethod, setPaymentMethod] = useState('stripe')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState('')

  const handleSubmit = (event) => {
    event.preventDefault()
    if (items.length === 0) {
      setStatus('Your cart is empty. Add a product first.')
      return
    }
    const orderSummary = items.map((item) => `${item.title} x${item.quantity}`).join(', ')
    setStatus(`Creating order for ${orderSummary}...`)

    ;(async () => {
      try {
        const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/shop-order`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, payment_method: paymentMethod, phone, items }),
        })

        const json = await res.json()
        if (!res.ok) throw new Error(json.error || 'Order creation failed')

        if (paymentMethod === 'stripe' && json.url) {
          // Redirect to Stripe Checkout
          window.location.href = json.url
        } else if (paymentMethod === 'paypal' && json.approveLink) {
          window.open(json.approveLink, '_blank')
          setStatus('Opened PayPal approval link. Complete payment to finish your order.')
        } else if (paymentMethod === 'mpesa') {
          setStatus('M-Pesa STK push initiated. Follow the prompts on your phone to complete payment.')
        } else {
          setStatus('Order created. Follow the provider instructions to complete payment.')
        }

        clearCart()
      } catch (err) {
        setStatus(err.message || 'Unable to create order')
      }
    })()
  }

  return (
    <div className="min-h-screen bg-ink-950 py-24">
      <div className="container-x">
        <div className="mx-auto max-w-4xl space-y-8">
          <div className="rounded-[32px] border border-white/10 bg-ink-900/80 p-8">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="eyebrow">Checkout</p>
                <h1 className="mt-3 text-3xl font-extrabold text-white">Review your order</h1>
                <p className="mt-2 text-sm text-slate-400">Use Stripe, PayPal, or M-Pesa to complete your purchase.</p>
              </div>
              <Link to="/shop" className="btn-ghost text-sm">
                Continue shopping
              </Link>
            </div>
          </div>

          <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <section className="rounded-[32px] border border-white/10 bg-ink-900/80 p-8">
              <h2 className="text-xl font-semibold text-white">Cart items</h2>
              {items.length === 0 ? (
                <div className="mt-8 rounded-3xl border border-white/10 bg-white/5 p-8 text-center text-slate-400">
                  Your cart is empty. Add a product from the shop.
                </div>
              ) : (
                <div className="mt-6 space-y-4">
                  {items.map((item) => (
                    <div key={item.slug} className="rounded-3xl border border-white/10 bg-slate-950/70 p-4">
                      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <p className="font-semibold text-white">{item.title}</p>
                          <p className="text-sm text-slate-400">{formatCurrency(item.price, item.currency)}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.slug, Number(e.target.value))}
                            className="w-20 rounded-2xl border border-white/10 bg-ink-950 px-3 py-2 text-sm text-white"
                          />
                          <button onClick={() => removeItem(item.slug)} className="text-sm font-semibold text-danger-300 hover:text-danger-200">
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <aside className="rounded-[32px] border border-white/10 bg-ink-900/80 p-8">
              <div className="space-y-6">
                <div>
                  <p className="text-sm uppercase tracking-[0.3em] text-slate-500">Order summary</p>
                  <p className="mt-3 text-3xl font-bold text-brand-300">{formatCurrency(total)}</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-[0.3em] text-slate-400">Payment method</p>
                    <div className="mt-3 space-y-3">
                      {paymentMethods.map((method) => (
                        <label key={method.id} className="flex items-center gap-3 rounded-3xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-300">
                          <input
                            type="radio"
                            name="paymentMethod"
                            value={method.id}
                            checked={paymentMethod === method.id}
                            onChange={() => setPaymentMethod(method.id)}
                            className="h-4 w-4 accent-brand-400"
                          />
                          {method.label}
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="block text-sm font-semibold text-slate-300">Email address</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(event) => setEmail(event.target.value)}
                      placeholder="you@example.com"
                      className="w-full rounded-3xl border border-white/10 bg-ink-950 px-4 py-3 text-sm text-white"
                    />
                  </div>

                  <div className="space-y-4">
                    <label className="block text-sm font-semibold text-slate-300">M-Pesa phone number</label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(event) => setPhone(event.target.value)}
                      placeholder="0712345678"
                      className="w-full rounded-3xl border border-white/10 bg-ink-950 px-4 py-3 text-sm text-white"
                    />
                  </div>

                  <button type="submit" className="btn-primary w-full rounded-full px-6 py-3 text-sm">
                    Submit order
                  </button>
                </form>

                {status && <p className="rounded-3xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">{status}</p>}
              </div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  )
}
