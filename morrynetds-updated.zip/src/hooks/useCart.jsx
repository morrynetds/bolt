import { useMemo, useState } from 'react'

export function useCart() {
  const [items, setItems] = useState([])

  const addItem = (product) => {
    setItems((current) => {
      const exists = current.find((item) => item.slug === product.slug)
      if (exists) {
        return current
      }
      return [...current, { ...product, quantity: 1 }]
    })
  }

  const removeItem = (slug) => {
    setItems((current) => current.filter((item) => item.slug !== slug))
  }

  const clearCart = () => setItems([])

  const total = useMemo(() => items.reduce((sum, item) => sum + item.price * item.quantity, 0), [items])

  return {
    items,
    addItem,
    removeItem,
    clearCart,
    total,
  }
}
