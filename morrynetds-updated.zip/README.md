# MorryNetPro

MorryNetPro is a marketing site and affiliate portal for an ICT trading tools product. Visitors can sign up as affiliates, log in to a dashboard to track referrals and commissions across a 6-tier network, request M-Pesa payouts, and (for active subscribers) access a gated trading dashboard.

## Tech stack

- React 18 + Vite
- React Router for client-side routing
- Tailwind CSS for styling
- Supabase (Postgres, Auth, Edge Functions) as the backend

## Running locally

```bash
npm install
npm run dev
```

The app needs two environment variables to talk to its Supabase backend:

```
VITE_SUPABASE_URL=your-project-url
VITE_SUPABASE_ANON_KEY=your-project-anon-key
```

Without these, the app still starts and renders — the login page shows a "backend not configured" notice and disables the login button instead of failing silently.

## Backend

Supabase migrations live in `supabase/migrations/` and define the affiliate, wallet, commission, subscription, shop order, and trial schema. A Supabase Edge Function in `supabase/functions/trading-dashboard/` serves the gated trading dashboard to subscribers only.

## Supabase setup

1. Create a Supabase project and note the `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
2. Set the Vite frontend env values in `.env`:

```env
VITE_SUPABASE_URL=your-project-url
VITE_SUPABASE_ANON_KEY=your-project-anon-key
```

3. Deploy the SQL migrations with Supabase CLI or the SQL editor, in order:
   - `supabase/migrations/20260717202121_create_morrynetpro_affiliate_schema.sql`
   - `supabase/migrations/20260718050102_create_subscriptions_table.sql`
   - `supabase/migrations/20260718124500_create_shop_and_trial_schema.sql`

4. Deploy the Edge Functions:
   - `supabase/functions/trading-dashboard/`
   - `supabase/functions/trial-registration/`
   - `supabase/functions/shop-order/`

5. Ensure the service role key is available in function environment variables as `SUPABASE_SERVICE_ROLE_KEY`.

## Shop and licensing

- The shop supports standalone HTML systems, EAS indicator packs, and trading utility suites.
- Each product is licensed to one user, with a unique license key generated at purchase.
- Shop purchases can be tracked with affiliate referral IDs for bonus credit.
