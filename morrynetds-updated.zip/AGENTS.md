# AGENTS.md

## Architecture

Single-page React app built with Vite, routed client-side with React Router (`src/main.jsx` → `src/App.jsx`). Three routes: `/` (marketing landing page), `/login`, `/dashboard`.

- `src/lib/supabase.js` — creates the Supabase client. Exports `isSupabaseConfigured`, which is `false` when `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` are absent. The client always falls back to a placeholder URL/key so `createClient()` never throws at import time — callers that need a real backend must check `isSupabaseConfigured` first.
- `src/lib/auth.jsx` — `AuthProvider`/`useAuth` wrap Supabase auth state. Skips calling Supabase entirely when `isSupabaseConfigured` is false.
- `src/components/ErrorBoundary.jsx` — top-level React error boundary rendered in `main.jsx`, shows a "refresh the page" fallback instead of a blank screen for any uncaught render error.
- `src/pages/Login.jsx`, `src/components/Signup.jsx` — auth forms. Login disables its submit button and shows a warning when Supabase isn't configured.
- `src/pages/Dashboard.jsx` — affiliate dashboard (overview, trading tools, downline, commission history, withdrawals). All `useState` calls are declared before any `useEffect` that closes over them — a prior version referenced state in a `useEffect` dependency array before that state's `const [...] = useState()` declaration ran, which threw a temporal-dead-zone error on every render.
- `supabase/migrations/` — SQL schema for affiliates, wallets, commissions, and subscriptions.
- `supabase/functions/trading-dashboard/` — Supabase Edge Function that gates the trading dashboard HTML behind an active subscription check.

## Conventions

- Components are `.jsx`, no TypeScript.
- Styling is Tailwind utility classes; custom design tokens (`ink`, `brand`, `ocean`, `gold`, `danger` color scales) are defined in `tailwind.config.js`.
- Supabase calls go through `src/lib/supabase.js` — don't instantiate `createClient` elsewhere.

## Non-obvious decisions

- The app must render even with no Supabase credentials set — this is intentional so the site doesn't fail as a blank page in environments where the backend hasn't been configured yet.
