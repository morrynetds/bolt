import { createClient } from 'npm:@supabase/supabase-js@2.45.0'
import Stripe from 'npm:stripe@12.16.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, Apikey, X-Client-Info',
}

function createLicenseKey(productSlug: string) {
  const random = crypto.getRandomValues(new Uint8Array(6)).reduce((acc, value) => acc + value.toString(36), '')
  return `${productSlug.slice(0, 3).toUpperCase()}-${random.toUpperCase()}`
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders })
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    )

    const url = new URL(req.url)

    // Helper: mark orders paid, credit affiliates, and update wallets
    async function processSuccessfulPayment(orderIds: string[], transactionId: string | null, provider: string) {
      if (!orderIds?.length) return
      for (const oid of orderIds) {
        // Mark order paid
        await supabase.from('shop_orders').update({ status: 'paid' }).eq('id', oid)

        // Fetch the order to see affiliate info
        const { data: orders } = await supabase.from('shop_orders').select('*').eq('id', oid).maybeSingle()
        const order = orders
        if (order && order.affiliate_id && Number(order.referral_credit) > 0) {
          const commission = {
            affiliate_id: order.affiliate_id,
            user_id: order.affiliate_id,
            transaction_id: oid,
            level: 1,
            amount: Number(order.referral_credit),
            status: 'completed',
          }
          await supabase.from('commissions').insert(commission)

          // Upsert wallet balance
          const { data: wallet } = await supabase.from('wallets').select('*').eq('affiliate_id', order.affiliate_id).maybeSingle()
          if (wallet) {
            await supabase.from('wallets').update({ current_balance: Number(wallet.current_balance) + Number(order.referral_credit) }).eq('affiliate_id', order.affiliate_id)
          } else {
            await supabase.from('wallets').insert({ affiliate_id: order.affiliate_id, current_balance: Number(order.referral_credit) })
          }
        }
      }
    }

    // Detect Stripe webhook via signature header
    const stripeSig = req.headers.get('stripe-signature')
    if (stripeSig) {
      const stripeSecret = Deno.env.get('STRIPE_SECRET')
      const stripeWebhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')
      if (!stripeSecret || !stripeWebhookSecret) return new Response('Missing stripe keys', { status: 400 })
      const payload = await req.text()
      const stripe = new Stripe(stripeSecret, { apiVersion: '2024-08-01' })
      let event
      try {
        event = stripe.webhooks.constructEvent(payload, stripeSig, stripeWebhookSecret)
      } catch (e) {
        return new Response(`Webhook Error: ${e.message}`, { status: 400 })
      }

      if (event.type === 'checkout.session.completed') {
        const session = event.data.object as any
        const order_ids = (session.metadata?.order_ids || '').split(',').filter(Boolean)
        await processSuccessfulPayment(order_ids, session.payment_intent || session.id, 'stripe')
      }
      return new Response(JSON.stringify({ received: true }), { status: 200 })
    }

    // Detect PayPal webhook by PayPal-specific headers
    if (req.headers.get('paypal-transmission-id')) {
      // Basic handler: capture and mark orders paid when PayPal notifies
      const bodyText = await req.text()
      const parsed = JSON.parse(bodyText || '{}')
      const eventType = parsed.event_type || parsed.eventType
      if (eventType === 'CHECKOUT.ORDER.APPROVED' || eventType === 'PAYMENT.CAPTURE.COMPLETED') {
        const resource = parsed.resource || {}
        const customId = resource.purchase_units?.[0]?.custom_id || resource.custom_id || ''
        const orderIds = (customId || '').split(',').filter(Boolean)
        await processSuccessfulPayment(orderIds, resource.id || null, 'paypal')
      }
      return new Response(JSON.stringify({ received: true }), { status: 200 })
    }

    // Detect M-Pesa callback by presence of `Body` or `stkCallback` field
    const textLookahead = await req.text()
    if (textLookahead && (textLookahead.includes('stkCallback') || textLookahead.includes('CallbackMetadata'))) {
      const mpesaBody = JSON.parse(textLookahead)
      // Attempt to extract AccountReference which contains our order ids
      const accountRef = mpesaBody.Body?.stkCallback?.CallbackMetadata?.Item?.find?.((i: any) => i.Name === 'AccountReference')?.Value || mpesaBody.Body?.stkCallback?.MerchantRequestID || ''
      const orderIds = (accountRef || '').toString().replace('Order:', '').split(',').filter(Boolean)
      if (orderIds.length) await processSuccessfulPayment(orderIds, mpesaBody.Body?.stkCallback?.CheckoutRequestID || null, 'mpesa')
      return new Response(JSON.stringify({ received: true }), { status: 200 })
    }

    // Otherwise treat as an order creation request
    const body = JSON.parse(textLookahead || '{}')
    const { email, payment_method, phone, items, affiliate_id, success_url, cancel_url } = body
    const { email, payment_method, phone, items, affiliate_id, success_url, cancel_url } = body

    if (!email || !items?.length) {
      return new Response(JSON.stringify({ error: 'Invalid order payload' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    if (!email || !items?.length) {
      return new Response(JSON.stringify({ error: 'Invalid order payload' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Create order rows first (pending) and return provider-specific session data below
    const licenseKeys: string[] = []
    const insertedRows: any[] = []

    for (const item of items) {
      const amount = Number(item.price) * Number(item.quantity || 1)
      const licenseKey = createLicenseKey(item.slug)
      const referralCredit = affiliate_id ? Number((amount * 0.1).toFixed(2)) : 0.0

      const { data, error } = await supabase.from('shop_orders').insert(
        {
          user_id: null,
          email,
          product_slug: item.slug,
          quantity: Number(item.quantity || 1),
          amount,
          currency: item.currency || 'USD',
          status: 'pending',
          license_key: licenseKey,
          affiliate_id: affiliate_id || null,
          referral_credit: referralCredit,
        },
        { returning: 'representation' },
      )

      if (error) {
        throw error
      }

      insertedRows.push(data?.[0] ?? null)
      licenseKeys.push(licenseKey)
    }

    const orderIds = insertedRows.map((r) => r.id).filter(Boolean)

    // Payment provider flows
    if (payment_method === 'stripe') {
      const stripeSecret = Deno.env.get('STRIPE_SECRET')
      if (!stripeSecret) throw new Error('Missing STRIPE_SECRET')
      const stripe = new Stripe(stripeSecret, { apiVersion: '2024-08-01' })

      const line_items = items.map((it: any) => ({
        price_data: {
          currency: (it.currency || 'USD').toLowerCase(),
          product_data: { name: it.title || it.slug },
          unit_amount: Math.round(Number(it.price) * 100),
        },
        quantity: Number(it.quantity || 1),
      }))

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'payment',
        line_items,
        success_url: success_url || (Deno.env.get('SHOP_SUCCESS_URL') || ''),
        cancel_url: cancel_url || (Deno.env.get('SHOP_CANCEL_URL') || ''),
        metadata: { order_ids: orderIds.join(','), affiliate_id: affiliate_id || '' },
      })

      return new Response(JSON.stringify({ url: session.url, id: session.id }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    if (payment_method === 'paypal') {
      // Create PayPal order server-side and return approval link
      const clientId = Deno.env.get('PAYPAL_CLIENT_ID')
      const secret = Deno.env.get('PAYPAL_SECRET')
      if (!clientId || !secret) throw new Error('Missing PayPal credentials')

      const authRes = await fetch('https://api-m.paypal.com/v1/oauth2/token', {
        method: 'POST',
        headers: { Authorization: 'Basic ' + btoa(`${clientId}:${secret}`), 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'grant_type=client_credentials',
      })
      const authJson = await authRes.json()
      const accessToken = authJson.access_token

      const purchase_units = [
        {
          amount: { currency_code: items[0].currency || 'USD', value: items.reduce((s: number, it: any) => s + Number(it.price) * Number(it.quantity || 1), 0).toFixed(2) },
          description: `Order ${orderIds.join(',')}`,
          custom_id: orderIds.join(','),
        },
      ]

      const orderRes = await fetch('https://api-m.paypal.com/v2/checkout/orders', {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ intent: 'CAPTURE', purchase_units }),
      })

      const orderJson = await orderRes.json()
      const approve = orderJson.links?.find((l: any) => l.rel === 'approve')?.href

      return new Response(JSON.stringify({ approveLink: approve, orderId: orderJson.id }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    if (payment_method === 'mpesa') {
      // Initiate an STK Push via Daraja (Safaricom) - requires MPESA credentials and callback URL
      const consumerKey = Deno.env.get('MPESA_CONSUMER_KEY')
      const consumerSecret = Deno.env.get('MPESA_CONSUMER_SECRET')
      const shortcode = Deno.env.get('MPESA_SHORTCODE')
      const passkey = Deno.env.get('MPESA_PASSKEY')
      const callbackUrl = Deno.env.get('MPESA_CALLBACK_URL') || (Deno.env.get('SHOP_SUCCESS_URL') || '')

      if (!consumerKey || !consumerSecret || !shortcode || !passkey) throw new Error('Missing M-Pesa credentials')

      const tokenRes = await fetch('https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials', {
        headers: { Authorization: 'Basic ' + btoa(`${consumerKey}:${consumerSecret}`) },
      })
      const tokenJson = await tokenRes.json()
      const accessToken = tokenJson.access_token

      const totalAmount = items.reduce((s: number, it: any) => s + Number(it.price) * Number(it.quantity || 1), 0)
      const timestamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14)
      const password = btoa(`${shortcode}${passkey}${timestamp}`)

      // Note: frontend must provide `phone` for STK push
      if (!phone) throw new Error('Phone number required for M-Pesa STK push')

      const stkRes = await fetch('https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest', {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          BusinessShortCode: shortcode,
          Password: password,
          Timestamp: timestamp,
          TransactionType: 'CustomerPayBillOnline',
          Amount: Math.round(totalAmount),
          PartyA: phone.replace('+', ''),
          PartyB: shortcode,
          PhoneNumber: phone.replace('+', ''),
          CallBackURL: callbackUrl,
          AccountReference: `Order:${orderIds.join(',')}`,
          TransactionDesc: `Purchase ${orderIds.join(',')}`,
        }),
      })

      const stkJson = await stkRes.json()
      return new Response(JSON.stringify({ mpesa: stkJson }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    return new Response(JSON.stringify({ success: true, licenseKeys, items: insertedRows }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
