import { createClient } from 'npm:@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, Apikey',
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 200, headers: corsHeaders })
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 })

  try {
    const body = await req.json()
    const { provider = 'paypal', limit = 10 } = body || {}

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    )

    // Fetch pending withdrawals
    const { data: withdrawals } = await supabase.from('withdrawals').select('*').eq('status', 'pending').limit(Number(limit))
    if (!withdrawals || withdrawals.length === 0) return new Response(JSON.stringify({ processed: 0 }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })

    let processed = 0

    if (provider === 'paypal') {
      const clientId = Deno.env.get('PAYPAL_CLIENT_ID')
      const secret = Deno.env.get('PAYPAL_SECRET')
      if (!clientId || !secret) throw new Error('Missing PayPal credentials')

      // Obtain access token
      const authRes = await fetch('https://api-m.paypal.com/v1/oauth2/token', {
        method: 'POST',
        headers: { Authorization: 'Basic ' + btoa(`${clientId}:${secret}`), 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'grant_type=client_credentials',
      })
      const authJson = await authRes.json()
      const accessToken = authJson.access_token

      // Build payouts batch
      const items = withdrawals.map((w: any, idx: number) => ({
        recipient_type: 'EMAIL',
        amount: { value: Number(w.amount).toFixed(2), currency: 'USD' },
        receiver: w.payout_details || w.phone || '',
        note: `MorryNetPro payout ${w.id}`,
        sender_item_id: w.id,
      }))

      const payoutBody = { sender_batch_header: { recipient_type: 'EMAIL', email_subject: 'You have a payout', email_message: 'Thanks for being an affiliate.' }, items }

      const payoutRes = await fetch('https://api-m.paypal.com/v1/payments/payouts', {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payoutBody),
      })

      const payoutJson = await payoutRes.json()
      // Mark withdrawals as completed locally (note: real-world should reconcile with PayPal batch status)
      for (const w of withdrawals) {
        await supabase.from('withdrawals').update({ status: 'completed' }).eq('id', w.id)
        // Deduct from wallet
        const { data: wallet } = await supabase.from('wallets').select('*').eq('affiliate_id', w.affiliate_id).maybeSingle()
        if (wallet) {
          await supabase.from('wallets').update({ current_balance: Number(wallet.current_balance) - Number(w.amount), total_withdrawn: Number(wallet.total_withdrawn) + Number(w.amount) }).eq('affiliate_id', w.affiliate_id)
        }
        processed += 1
      }

      return new Response(JSON.stringify({ processed, payoutBatch: payoutJson }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (provider === 'mpesa') {
      // M-Pesa B2C integration is region-specific; scaffold here
      // Implementors must provide MPESA_B2C_CONSUMER_KEY, MPESA_B2C_CONSUMER_SECRET
      return new Response(JSON.stringify({ error: 'M-Pesa B2C payout not implemented in this scaffold' }), { status: 501 })
    }

    return new Response(JSON.stringify({ processed }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  }
})
