import { createClient } from 'npm:@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, Apikey, X-Client-Info',
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders })
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    )

    const ipHeader = req.headers.get('x-forwarded-for') || req.headers.get('cf-connecting-ip') || req.headers.get('x-real-ip')
    const ipAddress = ipHeader ? ipHeader.split(',')[0].trim() : 'unknown'
    const body = await req.json()
    const deviceType = body.device_type || 'unknown'
    const deviceOs = body.device_os || 'unknown'
    const userAgent = body.user_agent || ''

    await supabase.from('trial_ips').delete().lte('trial_expires_at', new Date().toISOString())

    const { data: existing, error: selectError } = await supabase
      .from('trial_ips')
      .select('trial_expires_at')
      .eq('ip_address', ipAddress)
      .maybeSingle()

    if (selectError) {
      throw selectError
    }

    if (existing?.trial_expires_at) {
      return new Response(
        JSON.stringify({ error: 'A trial account has already been created from this IP address in the last 90 days.' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      )
    }

    const trialStartedAt = new Date().toISOString()
    const trialExpiresAt = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString()

    const { error: insertError } = await supabase.from('trial_ips').insert({
      ip_address: ipAddress,
      device_type: deviceType,
      device_os: deviceOs,
      user_agent: userAgent,
      trial_started_at: trialStartedAt,
      trial_expires_at: trialExpiresAt,
    })

    if (insertError) {
      throw insertError
    }

    return new Response(
      JSON.stringify({ trial_started_at: trialStartedAt, trial_expires_at: trialExpiresAt }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    )
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
