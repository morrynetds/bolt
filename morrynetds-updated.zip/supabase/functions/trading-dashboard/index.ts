import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid session" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = userData.user.id;
    const { data: sub, error: subError } = await supabase
      .from("subscriptions")
      .select("status, expires_at, is_trial, email_verified, trial_expires_at")
      .eq("user_id", userId)
      .maybeSingle();

    if (subError) {
      return new Response(JSON.stringify({ error: "Subscription check failed" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const now = new Date();
    const trialActive =
      sub?.is_trial === true &&
      sub?.email_verified === true &&
      (!sub?.trial_expires_at || new Date(sub.trial_expires_at) > now);

    const paidActive =
      sub?.status === "active" &&
      (!sub?.expires_at || new Date(sub.expires_at) > now);

    if (!trialActive && !paidActive) {
      const reason = sub?.is_trial && !sub?.email_verified
        ? "Please verify your email to activate your free trial."
        : sub?.is_trial && sub?.trial_expires_at && new Date(sub.trial_expires_at) <= now
        ? "Your 7-day free trial has ended. Subscribe to continue accessing the trading tools."
        : "An active subscription is required to access the trading tools.";
      return new Response(
        JSON.stringify({ error: reason }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const html = await Deno.readTextFile("./index.html");
    return new Response(html, {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
