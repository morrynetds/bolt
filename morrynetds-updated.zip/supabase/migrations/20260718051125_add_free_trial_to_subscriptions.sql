/*
# Add free trial support to subscriptions

1. Purpose
   - Every new user who verifies their email gets a 7-day free trial of the
     subscription service. After the trial, they must subscribe to keep access.
   - The trading dashboard edge function grants access during the trial OR
     while an active paid subscription exists.

2. Changes to existing tables
   - `subscriptions`
     - Add `trial_expires_at` (timestamptz, nullable) — end of the 7-day trial.
     - Add `is_trial` (boolean, default false) — distinguishes trial vs paid.
     - Add `email_verified` (boolean, default false) — set true when the user
       confirms their email, which activates the trial.

3. Security
   - No new tables. RLS already enabled; existing owner-scoped policies still apply.
   - No policy changes needed — new columns inherit existing row-level policies.

4. Notes
   - The Signup flow inserts a row with `is_trial = true`, `email_verified = false`,
     and `trial_expires_at = now() + interval '7 days'` once the user verifies email.
   - The edge function checks: (is_trial AND email_verified AND trial_expires_at > now())
     OR (status = 'active' AND (expires_at IS NULL OR expires_at > now())).
*/

ALTER TABLE subscriptions
  ADD COLUMN IF NOT EXISTS trial_expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS is_trial boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS email_verified boolean NOT NULL DEFAULT false;
