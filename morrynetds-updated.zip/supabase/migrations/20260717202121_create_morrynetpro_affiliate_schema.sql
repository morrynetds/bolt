/*
# MorryNetPro Affiliate Schema

1. Purpose
   - Stores the 6-tier affiliate network, commission ledger, wallet balances,
     and M-Pesa/PayPal withdrawal requests for the MorryNetPro platform.
   - Each authenticated user owns their affiliate profile, wallet, and
     commission/withdrawal rows.

2. New Tables
   - `affiliates`
     - `user_id` (uuid, PK, references auth.users, defaults to auth.uid())
     - `full_name` (text)
     - `phone` (text)
     - `payout_method` (text: 'mpesa' | 'paypal')
     - `payout_details` (text)
     - `parent_id` (uuid, nullable, references affiliates.user_id)
     - `tree_path` (text, materialized path of user ids separated by '-')
     - `join_date` (timestamptz, default now())
   - `commissions`
     - `id` (uuid, PK)
     - `affiliate_id` (uuid, references affiliates.user_id)
     - `user_id` (uuid, default auth.uid(), owner for RLS)
     - `transaction_id` (text, order/renewal id; '0' for manual entries)
     - `level` (int, 1-6 for tier commission, 0 for withdrawal)
     - `amount` (numeric, positive for credit, negative for withdrawal)
     - `status` (text, default 'pending')
     - `date` (timestamptz, default now())
   - `wallets`
     - `affiliate_id` (uuid, PK, references affiliates.user_id)
     - `user_id` (uuid, default auth.uid(), owner for RLS)
     - `current_balance` (numeric, default 0)
     - `total_withdrawn` (numeric, default 0)
   - `withdrawals`
     - `id` (uuid, PK)
     - `affiliate_id` (uuid, references affiliates.user_id)
     - `user_id` (uuid, default auth.uid(), owner for RLS)
     - `amount` (numeric)
     - `phone` (text)
     - `status` (text, default 'pending')
     - `requested_at` (timestamptz, default now())

3. Security
   - RLS enabled on all tables.
   - 4 owner-scoped policies (select/insert/update/delete) per table using auth.uid().
   - Owner columns default to auth.uid() so inserts omitting user_id still satisfy WITH CHECK.

4. Notes
   - tree_path uses a materialized path pattern for efficient 6-tier downline queries.
   - commissions.amount is signed: positive for credits, negative for withdrawals.
*/

-- affiliates
CREATE TABLE IF NOT EXISTS affiliates (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text NOT NULL,
  payout_method text NOT NULL DEFAULT 'mpesa',
  payout_details text NOT NULL,
  parent_id uuid REFERENCES affiliates(user_id) ON DELETE SET NULL,
  tree_path text NOT NULL DEFAULT '',
  join_date timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE affiliates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_affiliate" ON affiliates;
CREATE POLICY "select_own_affiliate" ON affiliates FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_affiliate" ON affiliates;
CREATE POLICY "insert_own_affiliate" ON affiliates FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_affiliate" ON affiliates;
CREATE POLICY "update_own_affiliate" ON affiliates FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_affiliate" ON affiliates;
CREATE POLICY "delete_own_affiliate" ON affiliates FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- wallets
CREATE TABLE IF NOT EXISTS wallets (
  affiliate_id uuid PRIMARY KEY REFERENCES affiliates(user_id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  current_balance numeric(12,2) NOT NULL DEFAULT 0.00,
  total_withdrawn numeric(12,2) NOT NULL DEFAULT 0.00
);

ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_wallet" ON wallets;
CREATE POLICY "select_own_wallet" ON wallets FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_wallet" ON wallets;
CREATE POLICY "insert_own_wallet" ON wallets FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_wallet" ON wallets;
CREATE POLICY "update_own_wallet" ON wallets FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_wallet" ON wallets;
CREATE POLICY "delete_own_wallet" ON wallets FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- commissions
CREATE TABLE IF NOT EXISTS commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_id uuid NOT NULL REFERENCES affiliates(user_id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  transaction_id text NOT NULL DEFAULT '0',
  level int NOT NULL DEFAULT 1,
  amount numeric(12,2) NOT NULL DEFAULT 0.00,
  status text NOT NULL DEFAULT 'pending',
  date timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_commissions_affiliate ON commissions(affiliate_id);
CREATE INDEX IF NOT EXISTS idx_commissions_level ON commissions(level);
CREATE INDEX IF NOT EXISTS idx_commissions_date ON commissions(date DESC);

ALTER TABLE commissions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_commissions" ON commissions;
CREATE POLICY "select_own_commissions" ON commissions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_commissions" ON commissions;
CREATE POLICY "insert_own_commissions" ON commissions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_commissions" ON commissions;
CREATE POLICY "update_own_commissions" ON commissions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_commissions" ON commissions;
CREATE POLICY "delete_own_commissions" ON commissions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- withdrawals
CREATE TABLE IF NOT EXISTS withdrawals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  affiliate_id uuid NOT NULL REFERENCES affiliates(user_id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL,
  phone text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  requested_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_withdrawals_affiliate ON withdrawals(affiliate_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status);

ALTER TABLE withdrawals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_withdrawals" ON withdrawals;
CREATE POLICY "select_own_withdrawals" ON withdrawals FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_withdrawals" ON withdrawals;
CREATE POLICY "insert_own_withdrawals" ON withdrawals FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_withdrawals" ON withdrawals;
CREATE POLICY "update_own_withdrawals" ON withdrawals FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_withdrawals" ON withdrawals;
CREATE POLICY "delete_own_withdrawals" ON withdrawals FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
