-- Shop and trial schema for MorryNetPro
-- Adds trial IP tracking, shop orders, and license enforcement.

-- trial_ips: restrict one trial per IP address every 90 days.
CREATE TABLE IF NOT EXISTS trial_ips (
  ip_address text PRIMARY KEY,
  device_type text,
  device_os text,
  user_agent text,
  trial_started_at timestamptz NOT NULL DEFAULT now(),
  trial_expires_at timestamptz NOT NULL DEFAULT now() + interval '90 days'
);

CREATE INDEX IF NOT EXISTS idx_trial_ips_expires ON trial_ips(trial_expires_at);

-- shop_orders: store purchases and one-user license assignments.
CREATE TABLE IF NOT EXISTS shop_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  email text NOT NULL,
  product_slug text NOT NULL,
  quantity int NOT NULL CHECK (quantity > 0),
  amount numeric(12,2) NOT NULL,
  currency text NOT NULL DEFAULT 'USD',
  status text NOT NULL DEFAULT 'pending',
  license_key text UNIQUE,
  affiliate_id uuid REFERENCES affiliates(user_id),
  referral_credit numeric(12,2) NOT NULL DEFAULT 0.00,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_shop_orders_user_product ON shop_orders(user_id, product_slug);

-- Cleanup helper for expired trial cache entries.
CREATE OR REPLACE FUNCTION cleanup_expired_trial_ips()
RETURNS void LANGUAGE sql AS $$
  DELETE FROM trial_ips WHERE trial_expires_at <= now();
$$;
