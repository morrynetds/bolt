/*
# Create subscriptions table

1. Purpose
   - Tracks which users have an active subscription, gating access to the
     ICT Trading Dashboard (served via edge function).
   - One row per user. `status` is 'active' | 'expired' | 'cancelled'.

2. New Tables
   - `subscriptions`
     - `user_id` (uuid, PK, references auth.users, defaults to auth.uid())
     - `status` (text, default 'active')
     - `tier` (text, default 'pro')
     - `started_at` (timestamptz, default now())
     - `expires_at` (timestamptz, nullable)

3. Security
   - RLS enabled.
   - Owner-scoped CRUD policies using auth.uid().
   - The edge function uses the service role key (bypasses RLS) to verify
     subscription status server-side before serving the gated HTML.
*/

CREATE TABLE IF NOT EXISTS subscriptions (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'active',
  tier text NOT NULL DEFAULT 'pro',
  started_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz
);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_subscription" ON subscriptions;
CREATE POLICY "select_own_subscription" ON subscriptions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_subscription" ON subscriptions;
CREATE POLICY "insert_own_subscription" ON subscriptions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_subscription" ON subscriptions;
CREATE POLICY "update_own_subscription" ON subscriptions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_subscription" ON subscriptions;
CREATE POLICY "delete_own_subscription" ON subscriptions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
